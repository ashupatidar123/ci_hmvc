<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class View extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
        $this->load->model('AdminModel');
        $this->load->helper('custom_helper');
        $this->load->library('admin/validation'); 
    }

    public function changePassword(){
        $this->adminHeader();
        $this->load->view('changePassword');
        $this->adminFooter();       
    }

    public function adminProfile(){

        $admin_id = $this->session->userdata('admin_id');
        $where = array('user_id'=>$admin_id);
        $select = 'name,mobile,email,location_url';
        $data['record'] = current($this->AdminModel->fetchQuery($select,'users',$where));
            
        $this->adminHeader();
        $this->load->view('adminProfile',$data);
        $this->adminFooter();       
    }

}//class end
