<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Custom{

	var $CI;
    public function __construct($params = array())
    {
        $this->CI =& get_instance();
    }

    function check_required_value($chk_params,$converted_array)
	{
	    foreach ($chk_params as $param)
	    {
	        if(array_key_exists($param, $converted_array) && ($converted_array[$param] !='')){
	            $check_error = 0;
	        } 
	        else{
	            $check_error=array('error'=>1,'param'=>$param);
	            break;
	        }
	    }
	    
	    if($check_error['error']>0){
	    	$resp = array('code'=>'501','message'=>'Missing '.ucfirst($check_error['param']));
		    print_r(json_encode(($resp))); die();
	    }
	} 





} // class end CustomLibrary

?>