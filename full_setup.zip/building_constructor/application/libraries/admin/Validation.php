<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Validation{

	var $CI;
    public function __construct($params = array())
    {
        $this->CI =& get_instance();        
    }

    function check_required_value($chk_params,$converted_array,$url='')
	{
	    foreach ($chk_params as $param)
	    {
	        if(array_key_exists($param, $converted_array) && ($converted_array[$param] !='')){
	            $check_error = 0;
	        } 
	        else{
	            $check_error=array('error'=>1,'param'=>$param);
	            break;
	        }
	    }
	    
	    if($check_error['error']>0){
	    	$error = $check_error['param'];
	    	$msg = array('message'=>"<strong>Opps! </strong>'".ucfirst($error)."' is required...",'alert'=>'alert alert-danger');
	    	$this->CI->session->set_flashdata('response',$msg);
			if($url==""){
				redirect($_SERVER['HTTP_REFERER']);
			}
			else{
				redirect($url);
			}

	    	//$resp = array('code'=>'50122','message'=>'Missing '.ucfirst($check_error['param']));
		    //print_r(json_encode(($msg))); die();
	    }
	} 





} // class end CustomLibrary

?>