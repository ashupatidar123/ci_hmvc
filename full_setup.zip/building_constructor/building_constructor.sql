-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 18, 2020 at 07:18 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `building_constructor`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 Active / 0 Inactive',
  `register_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_status`, `register_date`) VALUES
(1, 'Php', 1, '2020-03-13 12:18:10'),
(2, 'Java', 1, '2020-03-13 12:18:10'),
(3, 'Angular', 1, '2020-03-13 12:18:51'),
(4, 'C++', 1, '2020-03-13 12:18:51'),
(5, 'HTML', 1, '2020-03-13 12:19:06'),
(6, 'XML', 1, '2020-03-13 12:19:06'),
(7, 'Wordpress', 1, '2020-03-13 12:19:25'),
(8, 'Megento', 1, '2020-03-13 12:19:25'),
(9, 'Data Structure', 1, '2020-03-13 12:19:53'),
(10, 'CSS', 1, '2020-03-13 12:19:53'),
(11, 'C Sharp', 1, '2020-03-13 12:20:15'),
(12, '.Net', 1, '2020-03-13 12:20:15');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_products`
--

CREATE TABLE `supplier_products` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_products`
--

INSERT INTO `supplier_products` (`id`, `user_id`, `product_id`) VALUES
(1, 1, '30,34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(400) NOT NULL,
  `location_url` text NOT NULL COMMENT 'role admin (About insert)',
  `user_role` varchar(12) NOT NULL DEFAULT 'owner' COMMENT 'owner,supplier',
  `user_status` tinyint(4) NOT NULL DEFAULT 1,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `register_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `token` varchar(500) NOT NULL COMMENT 'Authorization Token for header',
  `fcm_token` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `mobile`, `email`, `password`, `location_url`, `user_role`, `user_status`, `updated_date`, `register_date`, `token`, `fcm_token`) VALUES
(1, 'Hare krishna', '9907166210', 'hari@webdesky.com', 'ODFydDgxZGM5YmRiNTJkMDRkYzIwMDM2ZGJkODMxM2VkMDU1bQmkdr', 'https://www.google.com/maps/place/Near+Sai+Mandir,+Indore,+Madhya+Pradesh/@22.7410124,75.8762841,17z/data=!3m1!4b1!4m5!3m4!1s0x3962fd5db950ec93:0xc57bfd50cf2dccda!8m2!3d22.7410892!4d75.8785397', 'supplier', 1, '2020-03-16 08:01:31', '2020-03-16 08:01:31', '', '46gdsddfsfsfsf'),
(2, 'Ashvin', '9907166213', 'ashvin@webdesky.com', 'ODFydDgxZGM5YmRiNTJkMDRkYzIwMDM2ZGJkODMxM2VkMDU1bQmkdr', 'https://www.google.com/maps/place/Near+Sai+Mandir,+Indore,+Madhya+Pradesh/@22.7410124,75.8762841,17z/data=!3m1!4b1!4m5!3m4!1s0x3962fd5db950ec93:0xc57bfd50cf2dccda!8m2!3d22.7410892!4d75.8785397', 'owner', 1, '2020-03-16 08:02:35', '2020-03-16 08:02:35', 'R5Z@l8Kiadlr6JyqNDp9muhG2dk$kgsbnQk6dSy6A2RLdY7f6vbg06JekXchcpp1tMgN1Q2@ka373OW', 'erqdsfsdddfsf'),
(3, 'Admin', '6784751254', 'admin@gmail.com', 'ODFydDgxZGM5YmRiNTJkMDRkYzIwMDM2ZGJkODMxM2VkMDU1bQmkdr', 'About us is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'admin', 1, '2020-03-17 07:06:04', '2020-03-17 07:06:04', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_meta`
--

CREATE TABLE `user_meta` (
  `meta_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_ext` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_meta`
--

INSERT INTO `user_meta` (`meta_id`, `user_id`, `file_name`, `file_ext`) VALUES
(1, 1, 'd.jpeg', '.jpeg'),
(2, 1, 'images.jpeg', '.jpeg'),
(3, 2, 'arjun1.png', '.png'),
(4, 2, 'k1.jpg', '.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL,
  `role_status` int(11) NOT NULL COMMENT '1 Active / 0 Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `role`, `role_status`) VALUES
(1, 'admin', 1),
(2, 'owner', 1),
(3, 'supplier', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_name` (`product_name`);

--
-- Indexes for table `supplier_products`
--
ALTER TABLE `supplier_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_meta`
--
ALTER TABLE `user_meta`
  ADD PRIMARY KEY (`meta_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `supplier_products`
--
ALTER TABLE `supplier_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_meta`
--
ALTER TABLE `user_meta`
  MODIFY `meta_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
