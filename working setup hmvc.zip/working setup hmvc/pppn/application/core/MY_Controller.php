<?php
if(!defined('BASEPATH')){
    exit('No direct script access allowed');
}

require APPPATH . "third_party/MX/Controller.php";

class MY_Controller extends MX_Controller
{	
	//public static $instance=NULL;	
	function __construct(){
		parent::__construct();
		$this->load->model('common_model');
		if($this->uri->segment(1)=='admin'){
            if((get_cookie('pppnAdmin'))<=0){
                redirect(base_url('admin/'));
            }
        }
    }

	public function obj(){
		new stdClass();
	}

	public function adminHeader(){
		$this->load->view('admin/template/header');
	}

	public function adminFooter(){
		$this->load->view('admin/template/footer');
	}

    public function frontHeader(){
        $this->load->view('home/header');
    }

    public function frontFooter(){
        $this->load->view('home/footer');
    }

	public function singleImage($name,$path,$url=''){
        $config['allowed_types'] = '*';
        $config['upload_path']   = $path;        

        $dr_name = explode(".",$_FILES[$name]['name']);
        $ext = end($dr_name);
        $new_name = date('d-m-Y-').time().'.'.$ext;
        $config['file_name'] = $new_name;
        
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload($name)){
            $data = $this->upload->data();
            return $data['file_name'];            
        }
        else{
            //return $this->upload->display_errors();
            echo 'uploadProblem'; die();
        }
    }

    public function dynamicImageUploadMultiple($name='',$folder=''){
    	$imageArray = array();
	    $ImageCount = count($_FILES[$name]['name']);

	    for($i=0;$i<$ImageCount; $i++)
	    {
	        $_FILES['file']['name']       = $_FILES[$name]['name'][$i];
	        $_FILES['file']['type']       = $_FILES[$name]['type'][$i];
	        $_FILES['file']['tmp_name']   = $_FILES[$name]['tmp_name'][$i];
	        $_FILES['file']['error']      = $_FILES[$name]['error'][$i];
	        $_FILES['file']['size']       = $_FILES[$name]['size'][$i];

	        $config['allowed_types']  = '*';
	        $config['upload_path'] = $folder;

	        $this->load->library('upload',$config);
	        $this->upload->initialize($config);

	        if($this->upload->do_upload('file'))
	        {                
	            $data = $this->upload->data();                
	            //$uploadImgData[$i][$name] = $data['file_name'];
	            $uploadImgData[$i][$name] = array("file_name"=>$data['file_name'],"file_ext"=>$data['file_ext']);	            
	            $imageArray[] = $uploadImgData[$i][$name];	            

	        }else{	            
	            $error = $this->upload->display_errors();
		        $str = array("<p>","</p>");
		        $error = str_replace($str,'',$error);
		        $resp = array('code'=>201,'status'=>false,'message'=>$error,'response'=>array('data'=>$error));
	        	response($resp); 
	        }
	    }
	    return $imageArray;
	}

	public function paginationRecord($total,$pagename,$uri_segment='3',$start_limit=0,$end_limit=50){      

        $this->load->library('pagination');  
        $config = array();
        $config["base_url"] = base_url().$pagename;
        $config["total_rows"] = $total;
        $config["per_page"] = $end_limit;
        $config["uri_segment"] = $uri_segment;        

        $config['cur_tag_open'] = '&nbsp;<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);

        $page = $start_limit;
        return $this->pagination->create_links();

    }

    function sendEmail($to,$subject,$template,$title){

        $from = 'support@pppn.com';
        $this->load->library('email'); //ci lib

        $config['protocol'] = 'sendmail'; // sendmail , smtp
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_port'] = 465;
        $config['smtp_timeout'] = '7';
        $config['smtp_user'] = 'awt.honest2019@gmail.com';
        $config['smtp_pass'] = 'ios@@developers22';
        $config['charset'] = 'iso-8859-1';
        $config['newline'] = "\r\n";
        $config['mailtype'] = 'html';
        $config['validation'] = TRUE;
        $config['wordwrap'] = TRUE;
        $config['mailpath'] = '/usr/sbin/sendmail'; 

        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from($from, $title);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($template);
        //pr($this->email->send());
        if ($this->email->send()) {
            return true;
        } else {
            return false;
        }
	}
}
