<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//$route['default_controller'] = 'welcome';
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


// Admin routes start
$route['admin'] = 'admin/login';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/logout']    = 'admin/dashboard/logout';

$route['admin/changePassword'] 		= 'admin/profile/changePassword';
$route['admin/profile'] 			= 'admin/profile/profile';

$route['admin/userList'] 			= 'admin/user/list';
$route['admin/userList/(:any)'] 	= 'admin/user/list/$1';
$route['admin/editUser/(:any)'] 	= 'admin/user/edit/$1';

$route['admin/addHospital'] 		= 'admin/hospital/add';
$route['admin/hospitalList'] 		= 'admin/hospital/list';
$route['admin/hospitalList/(:any)'] = 'admin/hospital/list/$1';
$route['admin/editHospital/(:any)'] = 'admin/hospital/edit/$1';

$route['admin/addQuestion'] 		= 'admin/question/add';
$route['admin/questionList'] 		= 'admin/question/list';
$route['admin/questionList/(:any)'] = 'admin/question/list/$1';
$route['admin/editQuestion/(:any)'] = 'admin/question/edit/$1';

$route['admin/addOption'] 			= 'admin/option/add';
$route['admin/optionList'] 			= 'admin/option/list';
$route['admin/optionList/(:any)'] 	= 'admin/option/list/$1';
$route['admin/editOption/(:any)']	= 'admin/option/edit/$1';

$route['admin/addLink'] 			= 'admin/setting/addLink';
// Admin routes end