<?php
header('Access-Control-Allow-Origin: *');
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MX_Controller
{
    public function __construct($config = 'rest'){
        parent::__construct($config);
        $this->load->model('APIModel');
    }

    public function modileCheck($mobile=''){
    	$where = array('userPhone'=>$mobile);
    	if(($this->APIModel->countQuery('users',$where))>0){
    		$resp = array('code'=>401,'status'=>false,'message'=>'Mobile number is already registered.','data'=>$where);
        	response($resp);
    	}else{
    		return true;
    	}
    }

    public function emailCheck($email=''){
    	$where = array('userEmail'=>$email,'userType'=>'USER');
    	if(($this->APIModel->countQuery('users',$where))>0){
    		$resp = array('code'=>401,'status'=>false,'message'=>'Email is already registered.','data'=>$where);
        	response($resp);
    	}else{
    		return true;
    	}
    }

	public function register(){
		$data  = $this->input->post();		
		$required_parameter = array('firstName','lastName','userEmail','userPhone','gender','region','peopleCount','userPassword');
	    check_required($required_parameter,$data);	
	    
	    $this->emailCheck($data['userEmail']);	
	    $this->modileCheck($data['userPhone']);
	    	    
	    $password = passwordGenerate($data['userPassword']);
		$insertData = array(
			'firstName'=>ucwords($data['firstName']),
			'lastName'=>ucwords($data['lastName']),
			'userEmail'=>$data['userEmail'],
			'userPhone'=>$data['userPhone'],
			'gender'=>ucfirst($data['gender']),
			'region'=>$data['region'],
			'userPassword'=>$password,				
			'peopleCount'=>$data['peopleCount'],
            'authToken'=>auth_token()
		);
		
		if(($lastId = $this->APIModel->insertQuery('users',$insertData))>0){
			$res_data = array(
                'userId'=>"$lastId",
                'firstName'=>ucwords($data['firstName']),
                'lastName'=>ucwords($data['lastName']),
                'userEmail'=>$data['userEmail'],
                'userPhone'=>$data['userPhone'],
                'gender'=>ucfirst($data['gender']),
                'region'=>$data['region'],
                'peopleCount'=>$data['peopleCount'],
                'authToken'=>auth_token()
            );
			$resp = array('code'=>200,'status'=>true,'message'=>'Registration success.','data' =>$res_data);  
		}else{
			$obj = new stdClass();
			$resp = array('success'=>401,'status'=>false,'message'=>'Registration failed.','data'=>$data);            
		}
		response($resp);
	}

	public function login(){
		
		$dt  = $this->input->post();
		$required_parameter = array('userEmail','userPassword');
	    check_required($required_parameter,$dt);
	    $password = passwordGenerate($dt['userPassword']);
	    $where = array('userPassword'=>$password,'userEmail'=>$dt['userEmail'],'userType'=>'USER');

	    if(!empty($user = current($this->APIModel->fetchQuery('*','users',$where)))){
    		$whereActive = array('userId'=>$user['userId'],'userStatus'=>'ACTIVE','isDeleted'=>'NO');
            if(($this->APIModel->countQuery('users',$whereActive))<=0){
                $resp = array('code'=>401,'status'=>false,'message'=>'Account is inactive.','data'=>new stdClass());
                response($resp);
            }
    			
            $authToken = auth_token();    
    		$holData= array(
    			'userId'=>$user['userId'],
    			'firstName'=>$user['firstName'],
    			'lastName'=>$user['lastName'],
    			'userPhone'=>$user['userPhone'],
    			'userEmail'=>$user['userEmail'],
    			'gender'=>$user['gender'],
    			'region'=>$user['region'],
    			'peopleCount'=>$user['peopleCount'],
                'authToken'=>$authToken,
                'isUserSubmitTest'=>($user['isUserSubmitTest']=='0')?false:true
    		);

            $update = array('authToken'=>$authToken);
            $this->APIModel->updateQuery('users',$update,$whereActive);
    		$resp = array('code'=>200,'status'=>true,'message'=>'Login success.','data'=>$holData);

    	}else{
    		$resp = array('code'=>401,'status'=>false,'message'=>'Invalid login details.','data'=>new stdClass());
    	}
    	response($resp);
	}

	public function sendEmail($to,$subject,$template,$title){

        $from = 'support@covidapp.com';
        $this->load->library('email'); //ci lib

        $config['protocol'] = 'sendmail'; // sendmail , smtp
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_port'] = 465;
        $config['smtp_timeout'] = '7';
        $config['smtp_user'] = 'awt.honest2019@gmail.com';
        $config['smtp_pass'] = 'ios@@developers22';
        $config['charset'] = 'iso-8859-1';
        $config['newline'] = "\r\n";
        $config['mailtype'] = 'html';
        $config['validation'] = TRUE;
        $config['wordwrap'] = TRUE;
        $config['mailpath'] = '/usr/sbin/sendmail'; 

        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from($from, $title);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($template);
        //pr($this->email->send());
        if ($this->email->send()) {
            return true;
        } else {
            return false;
        }
	}

	public function forgotPassword(){
		
		$dt  = $this->input->post();
		$required_parameter = array('userEmail');
	    check_required($required_parameter,$dt);
	    $where = array('userEmail'=>$dt['userEmail'],'userType'=>'USER');

	    if(!empty($user = current($this->APIModel->fetchQuery('userId,firstName,userStatus,otherKey','users',$where)))){
    		$whereActive = array('userId'=>$user['userId'],'userStatus'=>'ACTIVE','isDeleted'=>'NO');
            if(($this->APIModel->countQuery('users',$whereActive))<=0){
                $resp = array('code'=>401,'status'=>false,'message'=>'Account is inactive, please contact to support team.','data'=>new stdClass());
                response($resp);
            }
    			
    		$userId = $user['userId'];    		
    		if($user['otherKey']>0){
    			$otp = $user['otherKey'];
    		}else{
    			$otp = rand(111111,999999);
    		}

    		$currentDate = date('d F Y, H:i:s');
    		$htmlContent = ' 
		    <html> 
			    <head> 
			        <title>Reset password</title> 
			    </head> 
			    <body>			    
			        <h1 style="background-color: #ff000014;">Reset Password</h1> 
			        <table cellspacing="0" style="border:1px solid black;width:100%;font-size: 20px;text-align:left;padding:20px;"> 
			            <tr> 
			                <th>Dear '.$user['firstName'].',</th>
			            </tr> 
			            <tr> 
			                <th>OTP '.$otp.'</th>
			            </tr> 
			            <tr>
			            	<td>The password for your Covid account ('.$dt['userEmail'].') was successfully sent on '.$currentDate.'.</td>
			            </tr>

			            <tr>
			            	<p>Thank you,</p>
							<p>The Covid Team</p>
			            </tr>
			        </table>
				</body>
			</html>';

			$update = array('otherKey'=>$otp);
			$where = array('userId'=>$user['userId']);
			$this->APIModel->updateQuery('users',$update,$where);
			
			$subject = 'Reset password';
			$to  = $dt['userEmail'];
			$this->sendEmail($to,$subject,$htmlContent,$title='Reset password');
    		
			$res_data = array(
				'userId'=>$user['userId'],
				'userEmail'=>$dt['userEmail'],
				'otp'=>$otp
			);
    		$resp = array('code'=>200,'status'=>true,'message'=>'Forgot password sent successfully in your register email.','data'=>$res_data);

    	}else{
    		$resp = array('code'=>401,'status'=>false,'message'=>'Invalid email.','data'=>new stdClass());
    	}
    	response($resp);
	}

	public function updateResetPassword(){
		
		$dt  = $this->input->post();
		$required_parameter = array('otp','userPassword');
	    check_required($required_parameter,$dt);
	    $userPassword = passwordGenerate($dt['userPassword']);
	    $where = array('otherKey'=>$dt['otp'],'userType'=>'USER');

	    if(!empty($user = current($this->APIModel->fetchQuery('userId','users',$where)))){
    			
    		$update= array('userPassword'=>$userPassword,'otherKey'=>'');
    		$this->APIModel->updateQuery('users',$update,$where);
    		
    		$res_data = array('userId'=>$user['userId'],'otp'=>'');
    		$resp = array('code'=>200,'status'=>true,'message'=>'Password updated successfully.','data'=>$res_data);
    	}else{
    		$resp = array('code'=>401,'status'=>false,'message'=>'Invalid otp.','data'=>new stdClass());
    	}
    	response($resp);
	}

	public function peopleAndRegionList(){
		
		$where = array('status'=>'ACTIVE','isDeleted'=>'NO');
		$dbRegion = $this->APIModel->fetchQuery('regionId,regionName','region',$where);
		//pd($dbData);
        if(empty($dbRegion)){
            $resp = array('code'=>401,'status'=>false,'message'=>'Data not found.','data'=>new stdClass());
            response($resp);
        }

        $holData = array();
        foreach($dbRegion as $row){
        	$holData[] = array(
        		'id'=>$row['regionId'],
        		'name'=>$row['regionName']
        	);
        }
			
		$where  = array('status'=>'ACTIVE','isDeleted'=>'NO');
		$select = 'peopleId,peopleCount,peopleType';
		$dbPeople = $this->APIModel->fetchQuery($select,'people',$where);

		$holData1 = array();
        foreach($dbPeople as $row1){
        	$holData1[] = array(
        		'id'=>$row1['peopleId'],
                //'peopleCount'=>$row1['peopleCount'],
        		'name'=>$row1['peopleType']
        	);
        }
			
		$allData= array(
			'region'=>$holData,
			'people_count'=>$holData1
		);
		$resp = array('code'=>200,'status'=>true,'message'=>'success','data'=>$allData);
    	response($resp);
	}

	
}//class end
