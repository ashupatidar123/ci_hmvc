<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'modules/api/controllers/AuthCheck.php';
class Users extends AuthCheck
{
    public function __construct(){
        parent::__construct();
        //$this->authData['userId']
    }

    public function updateProfile(){
		$dt  = $this->input->post();		
		$required_parameter = array('userLatitude','userLongitude');
	    check_required($required_parameter,$dt);	
	    
	    $userId = $this->authData['userId'];
	    $where = array('userId'=>$userId);
	    	    
	    $update = array();

	    if(!empty($dt['firstName'])){
	    	$update['firstName'] = $dt['firstName'];
	    }
	    if(!empty($dt['lastName'])){
	    	$update['lastName'] = $dt['lastName'];
	    }
	    if(!empty($dt['gender'])){
	    	$update['gender'] = $dt['gender'];
	    }
	    if(!empty($dt['region'])){
	    	$update['region'] = $dt['region'];
	    }
	    if(!empty($dt['peopleCount'])){
	    	$update['peopleCount'] = $dt['peopleCount'];
	    }
	    if(!empty($dt['userLatitude'])){
	    	$update['userLatitude'] = $dt['userLatitude'];
	    }
	    if(!empty($dt['userLongitude'])){
	    	$update['userLongitude'] = $dt['userLongitude'];
	    }
		
		$this->APIModel->updateQuery('users',$update,$where);
		$u_data = $this->getUser($userId);
		$res_data = array(
            'userId'=>$u_data['userId'],
            'firstName'=>ucwords($u_data['firstName']),
            'lastName'=>ucwords($u_data['lastName']),
            'userEmail'=>$u_data['userEmail'],
            'userPhone'=>$u_data['userPhone'],
            'gender'=>ucfirst($u_data['gender']),
            'region'=>$u_data['region'],
            'peopleCount'=>$u_data['peopleCount'],
            'userLatitude'=>$u_data['userLatitude'],
            'userLongitude'=>$u_data['userLongitude']
        );
		$resp = array('code'=>200,'status'=>true,'message'=>'Profile updated successfully.','data'=>$res_data);  		
		response($resp);
	}

	public function fetchquestionlist(){
		$this->authData['userId'];
		$sLimit = ($this->input->post('start')>0)?$this->input->post('start'):'0';
	    $eLimit = ($this->input->post('end')>0)?$this->input->post('end'):'100';

		$where  = "isDeleted='NO'";
		$q_data = $this->APIModel->fetchQuery('questionId,questionName,questionType','questions',$where,$orderName=NULL,$ascDsc=NULL,$joinTbl=NULL,$joinId=NULL,$joinLR=NULL,$groupBy=NULL,$sLimit,$eLimit);
		
		if(!empty($q_data)){
			
			$holData = array();
			foreach($q_data as $val){
				$questionId = $val['questionId'];
				$where  = array('questionId'=>$questionId,'isDeleted'=>'NO');

				$o_data = $this->APIModel->fetchQuery('optionId,optionName,url','options',$where);
				$optionArray = array();
				foreach($o_data as $oVal){
					$optionArray[] = array(
						'optionId'=>$oVal['optionId'],
						'optionTitle'=>$oVal['optionName'],
						'url'=>!empty($oVal['url'])?$oVal['url']:''
					);
				}
				$holData[] = array(
					'questionId'=>$val['questionId'],
					'question'=>$val['questionName'],
					'questionType'=>$val['questionType'],
					'questionImage'=>'',
					'option'=>$optionArray
				);
			}
	
			$resp = array('code'=>200,'status'=>true,'message'=>'Questiones fetch successfully.','response'=>array('data'=>$holData));
        }else{
			$obj = new stdClass();
			$resp = array('success'=>400,'status'=>false,'message'=>'Data not found.','response'=>array('data'=>[]));            
		}
		response($resp);
	}

	public function addAnswer(){
		//$dt = '{"answer": [{"quesId": "1","optionId": "2"},{"quesId": "1","optionId": "2"},{"quesId": "1","optionId": "2"},{"quesId": "1","optionId": "2"}]}';
		if(empty($this->input->post('answer'))){
			$resp = array('code'=>401,'status'=>false,'message'=>'Answer required.','data'=>new stdClass());
		}
		else{

			$userId = $this->authData['userId'];
			$dt = $this->input->post('answer');		
			$data = json_decode($dt);
			$data = $data->answer;
			//print_r($data); die;
			foreach($data as $key=>$ans){
				$questionId = $ans->quesId;
				$optionId   = $ans->optionId;
				
				$where = array('questionId'=>$questionId,'userId'=>$userId,'isDeleted'=>'NO');
				if(($this->APIModel->countQuery('userAnswer',$where))>0){
					$update = array('optionId'=>$optionId);
					$this->APIModel->updateQuery('userAnswer',$update,$where);
				}else{
					$insert = array(
						'userId'=>$this->authData['userId'],
						'questionId'=>$questionId,
						'optionId'=>$optionId
					);
					$this->APIModel->insertQuery('userAnswer',$insert);
				}	
			}
			$updateUser = array('isUserSubmitTest'=>'1');
			$whereUser = array('userId'=>$userId);
			$this->APIModel->updateQuery('users',$updateUser,$whereUser);
			$resp = array('code'=>200,'status'=>true,'message'=>'Answer submitted successfully.');
		}
		
		response($resp);
	}
	
}//class end
