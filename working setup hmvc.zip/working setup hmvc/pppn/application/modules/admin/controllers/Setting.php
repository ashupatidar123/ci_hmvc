<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function addLink(){
        
        $where_ios = array('metaKey'=>'iosLink','isDeleted'=>'NO'); 
        $data['ios'] = current($this->common_model->fetchQuery('metaValue','setting',$where_ios));

        $where_andr = array('metaKey'=>'androidLink','isDeleted'=>'NO'); 
        $data['android'] = current($this->common_model->fetchQuery('metaValue','setting',$where_andr));

        $this->adminHeader();
        $this->load->view('setting/add',$data);
        $this->adminFooter();
    }

    public function submitLink(){
        $dt = $this->input->post();
        
        if(!empty($dt['ios'])){
            $where  = array('metaKey'=>'iosLink','isDeleted'=>'NO');
            if(($this->common_model->countQuery('setting',$where))>0){
                $update = array('metaValue'=>$dt['ios']);
                $lastId = $this->common_model->updateQuery('setting',$update,$where);
            }else{
                $insertData = array(
                    'metaKey'=>'iosLink',
                    'metaValue'=>$dt['ios']
                );
                $lastId = $this->common_model->insertQuery('setting',$insertData);
            }    
        }

        if(!empty($dt['android'])){
            $where  = array('metaKey'=>'androidLink','isDeleted'=>'NO');
            if(($this->common_model->countQuery('setting',$where))>0){
                $update = array('metaValue'=>$dt['android']);
                $lastId = $this->common_model->updateQuery('setting',$update,$where);
            }else{
                $insertData = array(
                    'metaKey'=>'androidLink',
                    'metaValue'=>$dt['android']
                );
                $lastId = $this->common_model->insertQuery('setting',$insertData);
            }    
        }
        echo ($lastId>0)?'success':'fail';
    }


}

?>