<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function list(){
        
        $sLimit = ($this->uri->segment(3)>0)?$this->uri->segment(3):0;
        $eLimit = 50;
        $limit = "LIMIT $sLimit,$eLimit";
        $where = "WHERE isDeleted='NO' AND userType='USER'";
        $total = $this->common_model->customCount('users',$where);      
        $data['total'] = $total;
        $data['links'] = $this->paginationRecord($total,'admin/userList/','3',$sLimit,$eLimit);
        $data['sno'] = $sLimit+1;

        $data['result'] = $this->common_model->customFetch('*','users',$where,$groupBy=NULL,$orderName='ORDER BY userId DESC',$limit);
        //pd($data);
        $data['totalUser'] = $total;
        $this->adminHeader();
        $this->load->view('user/list',$data);
        $this->adminFooter();
    }

    public function delete(){
       $dt = $this->input->post();
       $id = decoding($dt['id']);
       $where = array('userId'=>$id);
       $update = array('isDeleted'=>'YES');
       $this->common_model->updateQuery('users',$update,$where);
       echo 'success';
    }

    public function edit($id){
        
        $userId = decoding($id,'','admin/userList/');
        $where = array('userId'=>$userId); 
        $data['record'] = current($this->common_model->fetchQuery('*','users',$where));
        $this->adminHeader();
        $this->load->view('user/edit',$data);
        $this->adminFooter();
    }

    public function updateUser(){
        $dt = $this->input->post();
        $userId = decoding($dt['id']);
        
        $update = array(
            'firstName'=>ucwords($dt['firstName']),
            'lastName'=>ucwords($dt['lastName']),
            'gender'=>!empty($dt['gender'])?$dt['gender']:'Male',
            'userLatitude'=>$dt['userLatitude'],
            'userLongitude'=>$dt['userLongitude']
        );

        $where = array('userId'=>$userId);
        $this->common_model->updateQuery('users',$update,$where);
        echo 'success'; die();
    }

    public function userStatus(){
        $dt = $this->input->post();
        $userId = decoding($dt['id']);
        $userStatus = ($dt['status']=='ACTIVE')?'INACTIVE':'ACTIVE';

        $where = array('userId'=>$userId);
        $update = array('userStatus'=>$userStatus);
        $this->common_model->updateQuery('users',$update,$where);
        echo 'success'; die();
    }

}

?>