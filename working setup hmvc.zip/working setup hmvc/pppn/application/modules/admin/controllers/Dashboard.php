<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function index(){
    	$this->adminHeader();
    	$this->load->view('dashboard');
    	$this->adminFooter();
    	//get_cookie('covidAdmin');
    }

    public function logout(){
    	delete_cookie('covidAdmin');
    	redirect(base_url('admin'));
    }
}

?>