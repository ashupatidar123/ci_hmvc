<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MX_Controller
{
    public function __construct(){
        parent::__construct();  
        $this->load->model('common_model');
        if((get_cookie('pppnAdmin'))>0){
            redirect(base_url('admin/dashboard'));
        }
    }

    public function index(){
    	$this->load->view('login');
    }

    public function adminLogin(){
        $dt = $this->input->post();
        $email    = $dt['email'];
        $password = encoding($dt['password']);
        
        $where = array('email'=>$email,'password'=>$password,'type'=>'ADMIN');
        $data = current($this->common_model->fetchQuery("id","admin",$where));
        if(empty($data)){
            echo 'invalidLogin'; die();
        }
        if($dt['remember']=='yes'){
            $time = 60*60*24*31*12;
        }else{
            $time = 60*60*1;
        }
        $id = $data['id'];
        set_cookie('pppnAdmin',$id,$time);
        echo 'success';
    }

}//class end
