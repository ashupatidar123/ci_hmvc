<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/dashboard/');?>"><i class="fa fa-list nav-icon"></i> Home</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Link</li>
                    </ol>
                </div>
                
            </div>            
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">APP Link</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm">
                    <div class="card-body">
                        <div class="row">                            
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>IOS APP Link</label>
                                    <input type="text" class="form-control" name="ios" autocomplete="off" id="ios" value="<?=!empty($ios['metaValue'])?$ios['metaValue']:'';?>">
                                    <span class="err" id="iosErr"></span>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Android APP Link</label>
                                    <input type="text" class="form-control" name="android" autocomplete="off" id="android" value="<?=!empty($android['metaValue'])?$android['metaValue']:'';?>">
                                    <span class="err" id="androidErr"></span>
                                </div>
                            </div>
                            <?php
                            if(empty($ios['metaValue']) && empty($android['metaValue'])){
                                $type = 'add';
                            }else{
                                $type = 'update';
                            }
                            ?>
                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="add('<?=$type;?>');"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Submit</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="col-sm-12" id="addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function add(form_type='add'){
        var error = checkError();
        if(error==false){
           return false;
        }

        var form_Data = new FormData($('#myForm')[0]);            
        $.ajax({
            method:"POST",
            url:base_url+"admin/setting/submitLink",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                //alert(resp); return false;
                $('#loader').hide();
                $('#button').show();
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    if(form_type=='add'){
                        var msg = 'Link added successfully.';
                    }else{
                        var msg = 'Link updated successfully.';
                    }
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html(msg);
                    timeOUT('#addMsg','refresh');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }


    function checkError(){
        $('.err').html('');
        var ios = $('#ios').val();
        var android = $('#android').val();

        if(ios=='' && android==''){
            $('#addMsg').addClass('alert alert-danger');
            $('#addMsg').html('One field is required.');
            timeOUT('#addMsg');
            return false;
        }
        return true;
    }

</script>