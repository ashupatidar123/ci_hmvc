<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/optionList/');?>"><i class="fa fa-list nav-icon"></i> Option List</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Option</li>
                    </ol>
                </div>
                
            </div>            
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Add Option</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Questions</label>
                                    <select class="form-control" name="questionId">
                                        <option value="" hidden="">Select question</option>
                                        <?php
                                        if(!empty($all_qstn)){
                                            foreach($all_qstn as $q){
                                                $selected = ($q['questionId']==$qstn['questionId'])?'selected':'';
                                                echo '<option '.$selected.' value="'.$q['questionId'].'">'.$q['questionName'].'</option>';
                                            }
                                        }else{
                                           echo '<option value="" hidden="">Data not found</option>';
                                        }
                                        ?>
                                    </select>
                                    <span class="err" id="questionNameErr"></span>
                                </div>
                            </div>

                            <?php 
                                $sno=1;
                                foreach($option as $opt){

                                
                                ?>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Option <?=$sno;?></label>
                                        <input type="text" class="form-control" name="optionName[]" autocomplete="off" id="option<?=$sno;?>" value="<?=$opt['optionName'];?>">
                                        <span class="err" id="optionNameErr<?=$sno;?>"></span>                                    
                                    </div>
                                </div>
                                <?php
                                $sno++;
                            }?>    

                            
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Url</label>
                                    <input type="url" class="form-control" name="url" autocomplete="off" id="url" value="<?=!empty($optionUrl['url'])?$optionUrl['url']:'';?>">
                                    <span class="err" id="urlErr"></span>                                    
                                </div>
                            </div>
                            <input type="hidden" name="id" value="<?=$id;?>">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="update();"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Submit</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="col-sm-12" id="addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function update(){
        var error = checkError();
        if(error==false){
           return false;
        }
        
        var form_Data = new FormData($('#myForm')[0]);            
        $.ajax({
            method:"POST",
            url:base_url+"admin/option/updateOption",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                $('#loader').hide();
                $('#button').show();
                var url = base_url+'admin/optionList/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Successfully updated.');
                    timeOUT('#addMsg',url);
                }                
                else{
                    location.reload();
                }           
            }
        });
    }


    function checkError(){
        $('.err').html('');
        var questionName = $('select[name="questionId"]').val();
        
        var option1 = $('#option1').val();
        var option2 = $('#option2').val();
        var option3 = $('#option3').val();
        var option4 = $('#option4').val();
        
        if(questionName==''){
            $('#questionNameErr').html('Question field is requred');
        }
        if(option1==''){
            $('#optionNameErr1').html('Option one is requred');
        }
        if(option2==''){
            $('#optionNameErr2').html('Option two is requred');
        }
        if(option3==''){
            $('#optionNameErr3').html('Option three is requred');
        }
        if(option4==''){
            $('#optionNameErr4').html('Option four is requred');
        }
        if(questionName=='' || option1=='' || option2=='' || option3=='' || option4==''){
            return false;
        }
        return true;
    }
</script>