<footer class="main-footer">
    <strong>Copyright &copy; 2020-2025 <a target="_blank" href="http://sstechnology.in/">SS Tech</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.5
    </div>
</footer>
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div><!-- header wrapper -->

<script src="<?=base_url('assets/admin/lite/js/jquery-ui.min.js');?>"></script>
<script src="<?=base_url('assets/admin/lite/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?=base_url('assets/admin/lite/js/adminlte.js');?>"></script>
<script src="<?=base_url('assets/admin/lite/js/demo.js');?>"></script>
</body>
</html>

<script type="text/javascript">
    $(document).ready(function(){
        //alert('hy');
    });
</script>