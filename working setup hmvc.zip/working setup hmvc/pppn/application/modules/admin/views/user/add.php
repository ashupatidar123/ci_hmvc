<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/hospitalList/');?>"><i class="fa fa-list nav-icon"></i> Hospital List</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Hospital</li>
                    </ol>
                </div>
                
            </div>            
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Add Hospital</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" name="email" autocomplete="off">
                                    <span class="err" id="emailErr"></span>
                                </div>

                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" class="form-control" name="phone" autocomplete="off">
                                    <span class="err" id="phoneErr"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <input type="text" class="form-control" name="address" autocomplete="off">
                                    <span class="err" id="addressErr"></span>
                                </div>

                                <div class="form-group">
                                    <label>Details</label>
                                    <input type="text" class="form-control" name="details" autocomplete="off">
                                    <span class="err" id="detailsErr"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>latitude</label>
                                    <input type="text" class="form-control" name="latitude" autocomplete="off">
                                    <span class="err" id="latitudeErr"></span>
                                </div>

                                <div class="form-group">
                                    <label>Longitude</label>
                                    <input type="text" class="form-control" name="longitude" autocomplete="off">
                                    <span class="err" id="longitudeErr"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image" autocomplete="off">
                                    <span class="err" id="imageErr"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="add();"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Submit</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="col-sm-12" id="addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function add(){
        var error = checkError();
        if(error==false){
           return false;
        }
        
        var form_Data = new FormData($('#myForm')[0]);            
        $.ajax({
            method:"POST",
            url:base_url+"admin/hospital/submitHospital",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                $('#loader').hide();
                $('#button').show();

                var url = base_url+'admin/hospitalList/';
                if(resp=='uploadProblem'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Image uploading problem.');
                }
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('input').val('');
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Successfully added.');
                    timeOUT('#addMsg');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }


    function checkError(){
        var email = $('input[name="email"]').val();
        var phone = $('input[name="phone"]').val();
        var latitude = $('input[name="latitude"]').val();
        var longitude = $('input[name="longitude"]').val();
        
        if(email==''){
            $('#emailErr').html('Email is requred');
        }
        if(phone==''){
            $('#phoneErr').html('Phone is requred');
        }
        if(latitude==''){
            $('#latitudeErr').html('Latitude is requred');
        }
        if(longitude==''){
            $('#longitudeErr').html('Longitude is requred');
        }
        if(email=='' || phone=='' || latitude=='' || longitude==''){
            return false;
        }
        return true;
    }
</script>