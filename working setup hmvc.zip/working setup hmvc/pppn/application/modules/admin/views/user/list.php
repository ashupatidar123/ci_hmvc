<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">User</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-12" id="addMsg"></div> 
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title text-success">Total Users: <?=$totalUser;?> </h3>
                            <div class="card-tools" style="display: none;">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-head-fixed text-nowrap">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Action</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Gender</th>
                                        <th>Status</th>
                                        <th>Register Date</th>
                                        <th>User Image</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(!empty($result)):
                                    foreach($result as $row):
                                        $userId = encoding($row['userId']);
                                        $userStatus = $row['userStatus'];
                                        $userImage = !empty($row['userImage'])?base_url('uploads/users/').$row['userImage']:base_url('uploads/logo/user2.png');
                                        ?>
                                    <tr>
                                        <td><?=$sno++;?></td>
                                        <td>
                                            <a class="btn btn-primary btn-sm" href="<?=base_url('admin/editUser/').$userId;?>"><i class="fa fa-pencil"></i></a> 

                                            <a class="btn btn-danger btn-sm" href="javascript:void(0);" onclick="return deleteData('<?=$userId;?>','<?=$sno;?>');">
                                                <span id="trash<?=$sno;?>"><i class="fa fa-trash"></i></span> 
                                                <span id="trashLoader<?=$sno;?>" style="display: none;"><i class="fa fa-spinner fa-spin"></i></span>
                                            </a>

                                            <a class="btn btn-<?=($userStatus=='ACTIVE')?'info':'danger'?> btn-sm" href="javascript:void(0);" onclick="return accountStatus('<?=$userId;?>','<?=$sno;?>','<?=$userStatus;?>');">
                                                <span id="account<?=$sno;?>"><i class="fa fa-<?=($userStatus=='ACTIVE')?'check':'close'?>"></i></span> 
                                                <span id="accountLoader<?=$sno;?>" style="display: none;"><i class="fa fa-spinner fa-spin"></i></span>
                                            </a>
                                            
                                        </td>
                                        <td><?=$row['firstName'];?></td>
                                        <td><?=$row['userEmail'];?></td>
                                        <td><?=$row['userPhone'];?></td>
                                        <td><?=$row['gender'];?></td>
                                        <td><?=($row['userStatus']=='ACTIVE')?'<span style="color: #0ac70afa;font-style: italic;">Active</span>':'<span style="color: #f90303;font-style:italic;">In-Active</span>';?></td>
                                        <td><?=date('d/M/Y',strtotime($row['crd']));?></td>
                                        <td>
                                            <a href="<?=$userImage;?>" target="_blank"><img src="<?=$userImage;?>" alt="" width="50" height="40"></a>    
                                        </td>
                                    </tr>
                                    <?php
                                    endforeach; endif;?>                                    
                                </tbody>
                            </table>
                            <?php
                                if(empty($result))
                                    echo '<h3 class="alert alert-danger text-center">Record not found</h3>';
                            ?>
                        </div>
                        <div id="pagination">
                            <ul class="tsc_pagination">
                                <li>
                                <?php
                                    if(!empty($links)){
                                        echo $links;
                                    }
                                ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function deleteData(id,sno){
        $.ajax({
            method:"POST",
            url:base_url+"admin/user/delete",
            data:{id:id},
            beforeSend: function() {
                $('#trash'+sno).hide();
                $('#trashLoader'+sno).show();
            },
            success:function(resp)
            {
                $('#trashLoader'+sno).hide();
                $('#trash'+sno).show();
                var url = base_url+'admin/userList/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('input').val('');
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Deleted successfully.');
                    timeOUT('#addMsg','refresh');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }

    function accountStatus(id,sno,status){
        $.ajax({
            method:"POST",
            url:base_url+"admin/user/userStatus",
            data:{id:id,status:status},
            beforeSend: function() {
                $('#account'+sno).hide();
                $('#accountLoader'+sno).show();
            },
            success:function(resp)
            {
                //return alt(resp);
                $('#accountLoader'+sno).hide();
                $('#account'+sno).show();
                var url = base_url+'admin/userList/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    if(status=='ACTIVE'){
                      status = 'deactive';  
                    }else{
                        status = 'activate';
                    }
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Account '+status+' successfully.');
                    timeOUT('#addMsg','refresh');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }
</script>