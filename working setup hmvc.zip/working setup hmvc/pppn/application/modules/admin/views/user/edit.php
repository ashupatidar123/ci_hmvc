<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/userList/');?>"><i class="fa fa-list nav-icon"></i> User List</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">User</li>
                    </ol>
                </div>
                
            </div>            
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Edit User</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" class="form-control" name="firstName" autocomplete="off" value="<?=!empty($record['firstName'])?$record['firstName']:'';?>" style="text-transform: capitalize;">
                                    <span class="err" id="firstNameErr"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" name="userEmail" class="form-control" value="<?=$record['userEmail'];?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" name="userPhone" class="form-control" value="<?=$record['userPhone'];?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Pin Code</label>
                                    <input type="text" class="form-control" name="pinCode" autocomplete="off" value="<?=!empty($record['pinCode'])?$record['pinCode']:'';?>">
                                    <span class="err" id="pinCodeErr"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Gender</label><br>
                                    <label class="radio-inline"><input type="radio" name="gender" value="Male" <?=($record['gender']=='Male')?'checked':'';?>> Male</label>
                                    <label class="radio-inline"><input type="radio" name="gender" value="Female" <?=($record['gender']=='Female')?'checked':'';?>> Female</label>
                                    <label class="radio-inline"><input type="radio" name="gender" value="Other" <?=($record['gender']=='Other')?'checked':'';?>> Other</label>
                                    <span class="err" id="userLongitudeErr"></span>
                                </div>
                            </div>
                            <?php
                                $userImage = !empty($record['userImage'])?base_url('uploads/users/').$record['userImage']:base_url('uploads/logo/user2.png');
                            ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>User Image</label>
                                    <input type="file" class="form-control" name="userImage" autocomplete="off">
                                    <img src="<?=$userImage;?>" alt="" width="60" height="40">
                                </div>
                            </div>

                            <?php $id = $this->uri->segment(3);?>
                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="update('<?=$id;?>');"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Submit</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="col-sm-12" id="addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function update(id=''){
        $('#err').html('');
        var error = checkError();
        if(error==false || id==''){
           return false;
        }
        
        var form_Data = new FormData($('#myForm')[0]); 
        form_Data.append('id',id);           
        $.ajax({
            method:"POST",
            url:base_url+"admin/user/updateUser",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                //alert(resp); return false;
                $('#loader').hide();
                $('#button').show();
                var url = base_url+'admin/userList/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                    timeOUT('#addMsg');
                }
                else if(resp=='uploadProblem'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Image uploading problem.');
                    timeOUT('#addMsg');
                }
                else if(resp=='email'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Email is already exist.');
                    timeOUT('#addMsg');
                }
                else if(resp=='phone'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Phone is already exist.');
                    timeOUT('#addMsg');
                }
                else if(resp=='success'){
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Updated successfully.');
                    timeOUT('#addMsg',url);
                }                
                else{
                    location.reload();
                }           
            }
        });
    }


    function checkError(){
        var firstName = $('input[name="firstName"]').val();
        var lastName = $('input[name="lastName"]').val();
        var userLatitude = $('input[name="userLatitude"]').val();
        var userLongitude = $('input[name="userLongitude"]').val();
        
        if(firstName==''){
            $('#firstNameErr').html('First name is requred');
        }
        if(lastName==''){
            $('#lastNameErr').html('Last name is requred');
        }
        if(userLatitude==''){
            $('#userLatitudeErr').html('Latitude is requred');
        }
        if(userLongitude==''){
            $('#userLongitudeErr').html('Longitude is requred');
        }
        if(firstName=='' || lastName=='' || userLatitude=='' || userLongitude==''){
            return false;
        }
        return true;
    }
</script>