<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="<?=base_url('assets/admin/login_files/images/icons/favicon.ico')?>"/>

	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/admin/login_files/bootstrap.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/admin/login_files/fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/admin/login_files/fonts/iconic/css/material-design-iconic-font.min.css')?>">
	
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/admin/login_files/util.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/admin/login_files/main.css')?>">
	<style type="text/css">
		.err{
			color: red;
		}
	</style>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('<?=base_url('assets/admin/login_files/images/bg-01.jpg')?>');">
			<div class="wrap-login100">
				<form method="post" class="login100-form validate-form">
					<span class="login100-form-logo">
						<i class="zmdi zmdi-landscape"></i>
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Admin Login
					</span>		
					<div id="addMsg"></div>
					<div class="err"></div>			
					<div class="wrap-input100">
						<input class="input100" type="text" name="email" placeholder="Enter Email">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<input class="input-checkbox100" id="remember" type="checkbox" name="remember" value="yes">
						<label class="label-checkbox100" for="remember">
							Remember me
						</label>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="button" onclick="return login('admin');">
							<span style="display: none;" id="loader">
								<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Please wait...
							</span>
							<span id="button">Login</span>
						</button>
					</div>
					<div class="text-center p-t-90">
						<a class="txt1" href="#">
							<!-- Forgot Password? -->
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script src="<?=base_url('assets/admin/login_files/jquery-3.2.1.min.js')?>"></script>
</body>
</html>

<script type="text/javascript">
	var base_url = '<?=base_url();?>';
	function timeOUT(class_id_name='',reload='',time='2800'){
		setTimeout(function() { 
	        $(class_id_name).html('');
	        $(class_id_name).removeClass('alert alert-danger');
			$(class_id_name).removeClass('alert alert-success'); 
	    },time);
	    if(reload=='refresh'){
	    	setTimeout(function () { location.reload(1); }, 3000);
	    }else if(reload !=''){
	    	setTimeout(function () { window.location = reload; }, 3000);
	    }
	    else{
	    	return false;
	    }  
	}


	function login(type){
		$('.err').removeClass('alert alert-danger');
		$('.err').html('');
		var email = $('input[name="email"]').val();
		var password = $('input[name="password"]').val();
		var remember = $('#remember:checked').val();
		if(remember==undefined || remember==''){
			remember = 'no';
		}
		if(email=='' || password==''){
			$('.err').addClass('alert alert-danger');
			$('.err').html('Email & password is required.');
			return false;
		}

		$.ajax({
		    method:"POST",
		    url:base_url+"admin/login/adminLogin",
		    data: {email:email,password:password,remember:remember},
		    beforeSend: function() {
		    	$('#button').hide();
		      	$('#loader').show();
		    },
		    success:function(resp){	

		    	//alert(resp); return false;
			    var url = base_url+'admin/dashboard';

			    $('#loader').hide();
			    $('#button').show();
		      				    
			    if(resp=='invalidLogin'){
			    	$('#addMsg').addClass('alert alert-danger');
			    	$('#addMsg').html('Invalid email or password.');
			    }
			    else if(resp=='success'){
			    	$('input').val('');
			    	$('#addMsg').addClass('alert alert-success');
			    	$('#addMsg').html('Login successfully, redirecting...');
			    	timeOUT('',url);
			    }
			    if(resp!=''){
			    	timeOUT('#addMsg');
			    }else{
			    	window.location.reload();
			    }		    
		    }
	  	});
	}
</script>