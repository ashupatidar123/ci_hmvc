<?php

function response($data=''){
	echo json_encode($data); die();
}

function pd($data=''){
	echo "<pre>"; print_r($data); echo "</pre>"; die();
}

function passwordGenerate($password='1234'){
	$str = base64_encode('81rt'.md5($password).'m');
	return str_replace('==','mkdr', $str);
}

function auth_token(){
	return 'CVD_'.str_shuffle("ABC3DEF785HIJKLMN09OPQRSTUVWXYZ123K9RISHNA56");
}

function dateFormat($data){
	return date('d-M-Y',strtotime($data));
}

function stringReplace($data=''){
	$str = array("<p>","</p>","\"","\r\n","&nbsp;");
	return str_replace($str,'',$data);
}


function encoding($str='xyz'){
  	$one   = serialize($str);
  	$two   = @gzcompress($one,9);
  	$three = addslashes($two);
  	$four  = base64_encode($three);
  	$five  = strtr($four, '+/=', '-_.');
  	return $five;
  }

function decoding($str,$type='ajax',$url=''){
    $one   = strtr($str, '-_.', '+/=');
    $two   = base64_decode($one);
    $three = stripslashes($two);
    $four  = @gzuncompress($three);
    if ($four == '') {
	    if($type=='ajax'){
        echo 'fail'; die();
      }
      else if($url!=''){
		  	redirect(base_url($url));
	    }else{
		  	redirect(base_url());    
	    }
    }else {
        $five = unserialize($four);
        return $five;
    }
}


function check_required_value($chk_params, $converted_array)
{
    foreach ($chk_params as $param)
    {
        if(array_key_exists($param, $converted_array) && ($converted_array[$param] !='')){
            $check_error = 0;
        } 
        else{
            $check_error=array('check_error'=>1,'param'=>$param);
            break;
        }
    }
    return $check_error;
}


// THIS FUNCTION ONLY FOR API
function check_required($chk_params,$converted_array)
{
    foreach ($chk_params as $param)
    {
        if(array_key_exists($param, $converted_array) && ($converted_array[$param] !='')){
            $check_error=array('error'=>0,'param'=>$param);
        } 
        else{
            $check_error=array('error'=>1,'param'=>$param);
            break;
        }
    }
    
    if($check_error['error']>0){
      $resp = array('code'=>'501','message'=>'Missing '.ucwords($check_error['param']));
      print_r(json_encode(($resp))); die();
    }
}
?>