-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2020 at 02:49 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pppn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '''Admin''',
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `type` enum('ADMIN','SUPER_ADMIN') NOT NULL DEFAULT 'ADMIN',
  `status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `isDeleted` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `crd` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `type`, `status`, `isDeleted`, `crd`) VALUES
(1, 'Admin', 'admin@gmail.com', 'eNortjKxUjI0MjZRsgZcMA_ZAmU.', 'ADMIN', 'ACTIVE', 'NO', '2020-09-07 17:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `settingId` int(11) NOT NULL,
  `metaKey` varchar(100) NOT NULL,
  `metaValue` text DEFAULT NULL,
  `otherKey` varchar(50) DEFAULT NULL,
  `isDeleted` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `crd` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`settingId`, `metaKey`, `metaValue`, `otherKey`, `isDeleted`, `crd`) VALUES
(1, 'iosLink', 'h', NULL, 'NO', '2020-09-07 12:34:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `userEmail` varchar(50) NOT NULL,
  `userPhone` varchar(20) DEFAULT NULL,
  `pinCode` varchar(12) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL DEFAULT 'Male',
  `userType` enum('ADMIN','SUPER_ADMIN','USER') NOT NULL DEFAULT 'USER',
  `registerType` varchar(50) DEFAULT 'NORMAL',
  `userPassword` varchar(250) NOT NULL,
  `userStatus` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `userImage` varchar(100) DEFAULT NULL,
  `authToken` varchar(200) DEFAULT NULL,
  `emailVerify` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `isDeleted` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `otherKey` varchar(250) DEFAULT NULL,
  `fcmToken` varchar(400) DEFAULT NULL,
  `crd` timestamp NULL DEFAULT current_timestamp(),
  `upd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`settingId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `settingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
