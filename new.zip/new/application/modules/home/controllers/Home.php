<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MX_Controller
{
	function __construct() {
	    parent::__construct();
	    $this->load->model('HomeModel');
	    $this->load->helper('common_helper');
	    $this->load->library('my_encryption');
	}

	public function index()
	{
		$this->load->view('homePage');
	}

	public function login(){
		$this->load->view('login');
	}

	public function auth(){
		$data = $this->input->post();
		$id= $this->my_encryption->encode_id('4')."<br>";
		$this->my_encryption->decode_id($id);
		//$this->HomeModel->fetchQuery();
		//printData($data);

	}

	
}//class end
