<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends MX_Controller
{

	public function remove()
	{
		echo "remove index test";
	}



	
}//class end
