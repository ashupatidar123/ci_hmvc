<?php

function printData($data=''){
	echo "<pre>";
	print_r($data);
	echo "</pre>";
	die();
}



?>