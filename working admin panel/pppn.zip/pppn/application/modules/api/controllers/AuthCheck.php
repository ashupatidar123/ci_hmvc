<?php
header('Access-Control-Allow-Origin: *');
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthCheck extends MX_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->model('APIModel');
        $this->authData ='';
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Authorization");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Expose-Headers: Content-Length, X-JSON");
        header('Content-Type: application/json');
        
        if($_SERVER['REQUEST_METHOD'] == "OPTIONS") {
           	$error = array('code'=>401,'message'=>'Invalid method.');
        	echo json_encode($error); die();
        }
        else if(($this->input->get_request_header('authToken'))==''){
        	$error = array('code'=>401,'message'=>'Missing authToken.');
        	echo json_encode($error); die();
        }
        $authToken = $this->input->get_request_header('authToken');
        $where = array('authToken'=>$authToken);
        if(empty($user = current($this->APIModel->fetchQuery('*','users',$where)))){
        	$error = array('code'=>401,'message'=>'Unauthorized user.');
        	echo json_encode($error); die();
        }
        $this->authData = $user;
    }

    public function getUser($userId,$select='*'){
        $where = array('userId'=>$userId,'isDeleted'=>'NO','userStatus'=>'ACTIVE');
        $data = current($this->APIModel->fetchQuery($select,'users',$where));
        return $data;
    }
	
}//class end
