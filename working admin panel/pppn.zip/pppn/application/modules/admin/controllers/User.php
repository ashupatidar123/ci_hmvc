<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function list(){
        
        $this->adminHeader();
        $this->load->view('user/list');
        $this->adminFooter();
    }

    public function dataList($pno1=''){
        $pno = $this->input->post('pagno');
        $pageNum = ($pno==0)?0:$pno-1;        
        $eLimit = 50;
        $sLimit = ($pageNum*$eLimit);
        $limit = "LIMIT $sLimit,$eLimit";

        $where = "WHERE isDeleted='NO' AND userType='USER'";        
        if(!empty($this->input->post('search'))){
            $search = $this->input->post('search');
            $where .= " AND (firstName LIKE '%$search%' OR userEmail LIKE '%$search%' OR userPhone LIKE '%$search%')";
        }
        
        $total = $this->common_model->customCount('users',$where);              
        $links = $this->paginationRecord($total,'admin/user/dataList/','ajax',$sLimit,$eLimit);

        $data['total'] = $total;
        $data['links'] = $links;
        $data['sno']   = $sLimit;

        $data_result = $this->common_model->customFetch('*','users',$where,$groupBy=NULL,$orderName='ORDER BY userId ASC',$limit);

        $holeData = array();
        $sno = $sLimit+1;
        foreach($data_result as $key=>$row){
            
            $userId = encoding($row['userId']);
            $userStatus = $row['userStatus'];
            $icon = ($userStatus=='ACTIVE')?'check':'close';
            $btn = ($userStatus=='ACTIVE')?'info':'danger';

            $userImage = !empty($row['userImage'])?base_url('uploads/users/').$row['userImage']:base_url('uploads/logo/user2.png');

            $action = '<a class="btn btn-primary btn-sm" href="'.base_url('admin/user/edit/').$userId.'"><i class="fa fa-pencil"></i></a> ';

            $action .= 
                '<a class="btn btn-danger btn-sm" href="javascript:void(0);" onclick="return deleteData('."'".$userId."'".','.$pageNum.');"><i class="fa fa-trash"></i></a> ';

            $action .=    
                '<a class="btn btn-'.$btn.' btn-sm" href="javascript:void(0);" onclick="return accountStatus('."'".$userId."'".','."'".$userStatus."'".','.$pageNum.');">
                    <span id="account'.$sno.'"><i class="fa fa-'.$icon.'"></i></span> 
                    <span id="accountLoader'.$sno.'" style="display: none;"><i class="fa fa-spinner fa-spin"></i></span>
                </a>';

            $holeData[] = array(
                'userId'=>$row['userId'],
                'firstName'=>$row['firstName'],
                'userEmail'=>$row['userEmail'],
                'userPhone'=>$row['userPhone'],
                'crd'=>date('d/F/Y',strtotime($row['crd'])),                
                'userImage'=>$userImage,
                'action'=>$action,
                'pinCode'=>$row['pinCode'],
            );

            $sno++;
        }

        $data['result'] = $holeData;
        echo json_encode($data);
    }

    public function delete(){
       $dt = $this->input->post();
       $id = decoding($dt['id']);
       $where = array('userId'=>$id);
       $update = array('isDeleted'=>'YES');
       $this->common_model->updateQuery('users',$update,$where);
       echo 'success';
    }

    public function edit($id){
        
        $userId = decoding($id,'','admin/user/list/');
        $where = array('userId'=>$userId); 
        $data['record'] = current($this->common_model->fetchQuery('*','users',$where));
        $this->adminHeader();
        $this->load->view('user/edit',$data);
        $this->adminFooter();
    }

    public function updateUser(){
        $dt = $this->input->post();
        $userId = decoding($dt['id']);
        
        $userPhone = $dt['userPhone']; $userEmail = $dt['userEmail'];
        $wherePhone = array('userId!='=>$userId,'userPhone'=>$userPhone);
        $whereEmail = array('userId!='=>$userId,'userEmail'=>$userEmail);
        if($this->common_model->countQuery('users',$wherePhone)>0){
            echo 'phone'; die();
        }
        else if($this->common_model->countQuery('users',$whereEmail)>0){
            echo 'email'; die();
        }

        $update = array(
            'firstName'=>ucwords($dt['firstName']),
            'pinCode'=>$dt['pinCode'],
            'userPhone'=>$dt['userPhone'],
            'userEmail'=>$dt['userEmail'],
            'gender'=>!empty($dt['gender'])?$dt['gender']:'Male',
        );

        if(!empty($_FILES['userImage']['name'])){
            $update['userImage'] = $this->singleImage('userImage','uploads/users/');
        }
        
        $where = array('userId'=>$userId);
        $this->common_model->updateQuery('users',$update,$where);
        echo 'success'; die();
    }

    public function userStatus(){
        $dt = $this->input->post();
        $userId = decoding($dt['id']);
        $userStatus = ($dt['status']=='ACTIVE')?'INACTIVE':'ACTIVE';

        $where = array('userId'=>$userId);
        $update = array('userStatus'=>$userStatus);
        $this->common_model->updateQuery('users',$update,$where);
        echo 'success'; die();
    }

}

?>