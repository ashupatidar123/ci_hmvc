<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apartment extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function add(){
        
        $this->adminHeader();
        $this->load->view('apartment/add');
        $this->adminFooter();
    }

    public function submitApartment(){
        $dt = $this->input->post();
        
        $insert = array(
            'name'=>$dt['name'],
            'email'=>$dt['email'],
            'phone'=>$dt['phone'],
            'pinCode'=>$dt['pinCode'],
            'address'=>!empty($dt['address'])?$dt['address']:''
        );

        if(!empty($_FILES['image']['name'])){
            $insert['image'] = $this->singleImage('image','uploads/apartment/');
        }

        $lastId = $this->common_model->insertQuery('apartment',$insert);
        if($lastId>0){
            echo 'success';
        }else{
            echo 'fail';
        }
    }

    public function list(){
        
        $sLimit = ($this->uri->segment(3)>0)?$this->uri->segment(3):0;
        $eLimit = 30;
        $limit = "LIMIT $sLimit,$eLimit";
        $where = "WHERE isDeleted='NO'";
        $total = $this->common_model->customCount('apartment',$where);      
        $data['total'] = $total;
        $data['links'] = $this->paginationRecord($total,'admin/apartment/list/','3',$sLimit,$eLimit);
        $data['sno'] = $sLimit+1;

        $data['result'] = $this->common_model->customFetch('*','apartment',$where,$groupBy=NULL,$orderName='ORDER BY apartmentId DESC',$limit);
        //pd($data);
        $data['total'] = $total;
        $this->adminHeader();
        $this->load->view('apartment/list',$data);
        $this->adminFooter();
    }

    public function delete(){
       $dt = $this->input->post();
       $id = decoding($dt['id']);
       $where = array('apartmentId'=>$id);
       $update = array('isDeleted'=>'YES');
       $this->common_model->updateQuery('apartment',$update,$where);
       echo 'success';
    }

    public function edit($id){
        
        $userId = decoding($id,'','admin/apartment/list/');
        $where = array('apartmentId'=>$userId); 
        $data['record'] = current($this->common_model->fetchQuery('*','apartment',$where));
        $this->adminHeader();
        $this->load->view('apartment/edit',$data);
        $this->adminFooter();
    }

    public function updateApartment(){
        $dt = $this->input->post();
        $apartmentId = decoding($dt['id']);

        $update = array(
            'name'=>$dt['name'],
            'email'=>$dt['email'],
            'phone'=>$dt['phone'],
            'pinCode'=>$dt['pinCode'],
            'address'=>!empty($dt['address'])?$dt['address']:''
        );

        if(!empty($_FILES['image']['name'])){
            $update['image'] = $this->singleImage('image','uploads/apartment/');
        }

        $where = array('apartmentId'=>$apartmentId);
        $this->common_model->updateQuery('apartment',$update,$where);
        echo 'success'; die();
    }  

}

?>