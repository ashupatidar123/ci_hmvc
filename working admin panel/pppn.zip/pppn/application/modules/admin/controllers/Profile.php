<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller
{
    public function __construct(){
        parent::__construct();  
    }

    public function changePassword(){        
        $this->adminHeader();
        $this->load->view('profile/password');
        $this->adminFooter();
    }

    public function updatePassword(){
        $adminId = get_cookie('pppnAdmin');
        $cpass = $this->input->post('cpass');
        $opass = encoding($this->input->post('opass'));
        $where = array('id'=>$adminId,'password'=>$opass,'type'=>'ADMIN');
        
        $count = $this->common_model->countQuery('admin',$where);
        if($count<=0){
            echo 'oldPassword'; die();
        }
        $password = encoding($cpass);
        $update = array('password'=>$password);
        $this->common_model->updateQuery('admin',$update,$where);
        echo 'success'; die();
    }

    public function profile(){        
        $adminId = get_cookie('pppnAdmin');
        $name   = $this->input->post('name');
        $where  = array('id'=>$adminId);
        $data['record'] = current($this->common_model->fetchQuery('*','admin',$where));

        $this->adminHeader();
        $this->load->view('profile/profile',$data);
        $this->adminFooter();
    }

    public function updateProfile(){
        $adminId = get_cookie('pppnAdmin');
        $name   = $this->input->post('name');
        $where  = array('id'=>$adminId);
        $update = array('name'=>$name);
        $this->common_model->updateQuery('admin',$update,$where);
        echo 'success'; die();
    }
}

?>