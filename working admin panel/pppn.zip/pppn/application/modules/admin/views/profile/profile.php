<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/dashboard/');?>"><i class="fa fa-home nav-icon"></i> Home</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Admin Parofile</li>
                    </ol>
                </div>
                
            </div>            
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Admin Parofile</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" autocomplete="off" value="<?=$record['name'];?>">
                                    <span class="err" id="nameErr"></span>
                                </div>

                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" disabled="" value="<?=$record['email'];?>">
                                </div>

                            </div>

                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="update();"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Update</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="col-sm-12" id="addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function update(){
        $('.err').html('');
        var error = checkError();
        if(error==false){
           return false;
        }
        
        var form_Data = new FormData($('#myForm')[0]);            
        $.ajax({
            method:"POST",
            url:base_url+"admin/profile/updateProfile",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                $('#loader').hide();
                $('#button').show();
                var url = base_url+'admin/dashboard/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Profile updated successfully');
                    timeOUT('#addMsg','refresh');
                }if(resp!=''){
                    timeOUT('#addMsg');
                }               
                else{
                    location.reload();
                }           
            }
        });
    }

    function checkError(){
        var name = $('input[name="name"]').val();
        if(name==''){
            $('#nameErr').html('Name is requred.');
            return false;
        }
    }
</script>