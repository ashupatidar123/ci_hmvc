<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/apartment/list/');?>"><i class="fa fa-list nav-icon"></i> List</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Apartment</li>
                    </ol>
                </div>                
            </div>   
            <div class="err col-sm-12 addMsg"></div>         
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Add Apartment</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <form method="post" id="myForm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" autocomplete="off">
                                    <span class="err" id="nameErr"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" name="email" autocomplete="off">
                                    <span class="err" id="emailErr"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" class="form-control" name="phone" autocomplete="off">
                                    <span class="err" id="phoneErr"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Pin Code</label>
                                    <input type="text" class="form-control" name="pinCode" autocomplete="off">
                                    <span class="err" id="pinCodeErr"></span>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Address</label>
                                    <textarea class="form-control" name="address" rows="2" autocomplete="off" minlength="10" maxlength="999"></textarea>
                                    <span class="err" id="addressErr"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image" autocomplete="off">
                                    <span class="err" id="imageErr"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <button type="button" class="btn btn-primary" onclick="add();"><span id="loader" style="display: none;"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Please wait...</span> <span id="button">Submit</span></button>
                            </div>
                        </div>
                    </div>                    
                </form>
            </div> 
            <div class="err col-sm-12 addMsg"></div>           
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function add(){
        var error = checkError();
        if(error==false){
           return false;
        }
        
        var form_Data = new FormData($('#myForm')[0]);            
        $.ajax({
            method:"POST",
            url:base_url+"admin/apartment/submitApartment",
            contentType: false,
            processData: false,
            data: form_Data,
            beforeSend: function() {
                $('#button').hide();
                $('#loader').show();
            },
            success:function(resp)
            {
                $('#loader').hide();
                $('#button').show();
                //alert(resp); return false;
                var url = base_url+'admin/apartment/list/';
                if(resp=='uploadProblem'){
                    $('.addMsg').addClass('alert alert-danger');
                    $('.addMsg').html('Image uploading problem.');
                }
                if(resp=='fail'){
                    $('.addMsg').addClass('alert alert-danger');
                    $('.addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('input').val('');
                    $('.addMsg').addClass('alert alert-success');
                    $('.addMsg').html('Added successfully.');
                    timeOUT('.addMsg',url);
                }                
                else{
                    location.reload();
                }           
            }
        });
    }


    function checkError(){
        var name  = $('input[name="name"]').val();
        var email = $('input[name="email"]').val();
        var phone = $('input[name="phone"]').val();        
        var pinCode = $('input[name="pinCode"]').val();
        
        if(name==''){
            $('#nameErr').html('Name is requred.');
        }
        if(email==''){
            $('#emailErr').html('Email is requred.');
        }
        if(phone==''){
            $('#phoneErr').html('Phone is requred.');
        }
        if(pinCode==''){
            $('#pinCodeErr').html('Pin code is requred.');
        }
        if(name=='' || email=='' || phone=='' || pinCode==''){
            return false;
        }
        return true;
    }
</script>