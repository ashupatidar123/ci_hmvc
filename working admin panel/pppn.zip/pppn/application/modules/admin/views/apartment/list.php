<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <a class="btn btn-info" href="<?=base_url('admin/apartment/add/');?>"><i class="fa fa-plus nav-icon"></i> Add</a>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">Apartment</li>
                    </ol>
                </div>                
            </div>
            <div class="col-sm-12" id="addMsg"></div> 
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title text-success">Total Apartment: <?=$total;?> </h3>
                            <div class="card-tools" style="display: none;">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-head-fixed text-nowrap">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Action</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Pin Code</th>
                                        <th>Register Date</th>
                                        <th>Image</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(!empty($result)):
                                    foreach($result as $row):
                                        $apartmentId = encoding($row['apartmentId']);
                                        $image = !empty($row['image'])?base_url('uploads/apartment/').$row['image']:base_url('uploads/logo/user2.png');
                                        ?>
                                    <tr>
                                        <td><?=$sno++;?></td>
                                        <td>
                                            <a class="btn btn-primary btn-sm" href="<?=base_url('admin/apartment/edit/').$apartmentId;?>"><i class="fa fa-pencil"></i></a> 

                                            <a class="btn btn-danger btn-sm" href="javascript:void(0);" onclick="return deleteData('<?=$apartmentId;?>','<?=$sno;?>');">
                                                <span id="trash<?=$sno;?>"><i class="fa fa-trash"></i></span> 
                                                <span id="trashLoader<?=$sno;?>" style="display: none;"><i class="fa fa-spinner fa-spin"></i></span>
                                            </a>

                                        </td>
                                        <td><?=$row['name'];?></td>
                                        <td><?=$row['email'];?></td>
                                        <td><?=$row['phone'];?></td>
                                        <td><?=$row['pinCode'];?></td>
                                        <td><?=date('d/M/Y',strtotime($row['crd']));?></td>
                                        <td>
                                            <a href="<?=$image;?>" target="_blank"><img src="<?=$image;?>" alt="" width="50" height="40"></a>    
                                        </td>
                                    </tr>
                                    <?php
                                    endforeach; endif;?>                                    
                                </tbody>
                            </table>
                            <?php
                                if(empty($result))
                                    echo '<h3 class="alert alert-danger text-center">Record not found</h3>';
                            ?>
                        </div>
                        <div id="pagination">
                            <ul class="tsc_pagination">
                                <li>
                                <?php
                                    if(!empty($links)){
                                        echo $links;
                                    }
                                ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function deleteData(id,sno){
        $.ajax({
            method:"POST",
            url:base_url+"admin/apartment/delete",
            data:{id:id},
            beforeSend: function() {
                $('#trash'+sno).hide();
                $('#trashLoader'+sno).show();
            },
            success:function(resp)
            {
                $('#trashLoader'+sno).hide();
                $('#trash'+sno).show();
                var url = base_url+'admin/apartment/list/';
                if(resp=='fail'){
                    $('#addMsg').addClass('alert alert-danger');
                    $('#addMsg').html('Failed.');
                }
                else if(resp=='success'){
                    $('input').val('');
                    $('#addMsg').addClass('alert alert-success');
                    $('#addMsg').html('Deleted successfully.');
                    timeOUT('#addMsg','refresh');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }
</script>