<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard/');?>">Home</a></li>
                        <li class="breadcrumb-item active">User</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-12" id="addMsg"></div> 
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title text-success">Total Users: <span id="total"></span> </h3>
                            <div class="card-tools">
                                <form method="post">
                                    <div class="input-group input-group-sm" style="width:385px;">
                                        <input type="text" name="table_search" class="form-control float-right" placeholder="Search" onkeyup="return searchResult(this.value);">
                                        <input type="hidden" id="setSearch">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-head-fixed text-nowrap" id="appendTable">
                                <thead>
                                    <tr>
                                        <th>Sno.</th>
                                        <th>Action</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Register Date</th>
                                        <th>User Image</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>                           
                        </div>
                        <div id="pagination">
                            <ul class="tsc_pagination">
                                <li id="addLink"></li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<script type="text/javascript">
    function loadPagination(pagno='0',search=''){
        
        $.ajax({
            url: '<?=base_url('admin/user/dataList/')?>'+pagno,
            data:{pagno:pagno,search:search},
            type: 'post',
            dataType: 'json',
            success: function(response){
                //alert(response);
                if(response.total>0){
                    $('#pagination').show();
                    $('#loading').show();
                    var data = response.result;
                    $('#addLink').html(response.links);
                    $('#total').html(response.total);
                    
                    $('#appendTable tbody').empty();
                    var sno = response.sno;
                    for(i=0;i<data.length;i++){
                        
                        sno += 1;
                        var htmlData = 
                        '<tr>'+
                            '<td>'+sno+'</td>'+
                            '<td>'+data[i].action+'</td>'+
                            '<td>'+data[i].firstName+'</td>'+
                            '<td>'+data[i].userEmail+'</td>'+
                            '<td>'+data[i].userPhone+'</td>'+
                            '<td>'+data[i].crd+'</td>'+
                            '<td><img src='+data[i].userImage+' width="40" height="40"></td>'+
                        '</tr>';

                        $('#appendTable tbody').append(htmlData);
                    }
                }else{
                    $('#pagination').hide();
                    $('#total').html('0');
                    $('#appendTable tbody').empty();
                    snackbarMsg('Oops! Record not found.');
                }
                $('#loading').fadeOut(1000);                
            }
        });
        
     }

    $(document).ready(function(){
        $('#pagination').on('click','a',function(e){
            e.preventDefault(); 
            var pageno = $(this).attr('data-ci-pagination-page');
            var search = $('#setSearch').val();
            loadPagination(pageno,search);
        });
        loadPagination(0);
    });


    function deleteData(id='',pageno='0'){
        $.ajax({
            method:"POST",
            url:base_url+"admin/user/delete",
            data:{id:id},
            success:function(resp){
                if(resp=='fail'){
                    snackbarMsg('Failed.');
                }
                else if(resp=='success'){
                    var search = $('#setSearch').val();
                    loadPagination(pageno+1,search);
                    snackbarMsg('Deleted successfully..');
                }                
                else{
                    location.reload();
                }           
            }
        });
    }

    function accountStatus(id,status,pageNum='0'){
        $.ajax({
            method:"POST",
            url:base_url+"admin/user/userStatus",
            data:{id:id,status:status},
            success:function(resp){
                var url = base_url+'admin/user/list/';
                if(resp=='fail'){
                    snackbarMsg('Failed.');
                }
                else if(resp=='success'){
                    var search = $('#setSearch').val();
                    loadPagination(pageNum+1,search);
                    
                    if(status=='ACTIVE'){
                      status = 'deactive';  
                    }else{
                        status = 'active';
                    }
                    snackbarMsg('Account '+status+' successfully.');                    
                }                
                else{
                    location.reload();
                }           
            }
        });
    }   

    function searchResult(val){
        $('#setSearch').val(val);
        loadPagination(0,val);
    } 
</script>