<?php $pageName = $this->uri->segment(2);?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?=base_url('assets/admin/lite/css/all.min.css');?>">
        <link rel="stylesheet" href="<?=base_url('assets/common/css/my_custom.css');?>">
        <link rel="stylesheet" href="<?=base_url('assets/common/css/my_pagination.css');?>">
        <!-- <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css');?>"> -->
        <link rel="stylesheet" href="<?=base_url('assets/admin/lite/css/adminlte.min.css');?>">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="<?=base_url('assets/admin/lite/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('assets/common/sweetAlert/sweetalert.min.js');?>"></script>
        <script type="text/javascript">
            var base_url = '<?=base_url();?>';
        </script>
        <script src="<?=base_url('assets/admin/js/adminCustom.js');?>"></script>
    </head>
    <div id="loading" class="loading" style="display:none;">
        <img  src="<?=base_url('uploads/loader/load1.gif');?>">
    </div>
    <div id="snackbar"></div>
    <body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
            </ul>
            
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                    
                    <p><i class="fa fa-user"></i></p>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <span class="dropdown-item dropdown-header">Admin Setting</span>
                        <div class="dropdown-divider"></div>
                        <a href="<?=base_url('admin/profile');?>" class="dropdown-item">
                            <i class="fa fa-user-circle-o mr-2"></i> Profile
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="<?=base_url('admin/changePassword');?>" class="dropdown-item">
                            <i class="fa fa-lock mr-2"></i> Change Password
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="<?=base_url('admin/logout');?>" class="dropdown-item">
                            <i class="fa fa-sign-out mr-2"></i> Sign-out
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?=base_url('admin/dashboard');?>" class="brand-link">
            <img src="<?=base_url('assets/admin/dist/img/AdminLTELogo.png');?>" alt="" class="brand-image img-circle elevation-3"
                style="opacity: .8">
            <span class="brand-text font-weight-light">Admin</span>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex" style="display: none!important;">
                    <div class="image">
                        <img src="<?=base_url('assets/admin/dist/img/user2-160x160.jpg');?>" class="img-circle elevation-2" alt="">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block">Ashvin Patidar</a>
                    </div>
                </div>
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class
                            with font-awesome or any other icon font library -->
                        <li class="nav-item has-treeview menu-open">
                            <li class="nav-item">
                                <a href="<?=base_url('admin/dashboard');?>" class="nav-link <?=($pageName=='dashboard')?'active':''?>">
                                    <i class="nav-icon fas fa-tachometer-alt"></i>
                                    <p>Dashboard</p>
                                </a>
                            </li>
                        </li>
                                            
                        <li class="nav-item has-treeview <?=($pageName=='user')?'menu-open':''?>">
                            <a href="#" class="nav-link <?=($pageName=='user')?'active':''?>">
                                <i class="nav-icon fa fa-user"></i>
                                <p>User
                                   <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview" <?=($pageName=='user')?'style="display: block;"':''?>>
                                <li class="nav-item">
                                    <a href="<?=base_url('admin/user/list');?>" class="nav-link">
                                        <i class="fa fa-list nav-icon"></i>
                                        <p>User List</p>
                                    </a>
                                </li>                                
                            </ul>
                        </li>

                        <li class="nav-item has-treeview <?=($pageName=='apartment')?'menu-open':''?>">
                            <a href="#" class="nav-link <?=($pageName=='apartment')?'active':''?>">
                                <i class="nav-icon fa fa-building-o"></i>
                                <p>Apartment
                                   <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview" <?=($pageName=='apartment')?'style="display: block;"':''?>>
                                <li class="nav-item">
                                    <a href="<?=base_url('admin/apartment/add');?>" class="nav-link">
                                        <i class="fa fa-plus nav-icon"></i>
                                        <p>Add Apartment</p>
                                    </a>
                                </li>                                
                            </ul>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?=base_url('admin/apartment/list');?>" class="nav-link">
                                        <i class="fa fa-list nav-icon"></i>
                                        <p>Apartment List</p>
                                    </a>
                                </li>                                
                            </ul>
                        </li> 

                        <li class="nav-item has-treeview <?=($pageName=='addLink')?'menu-open':''?>">
                            <a href="#" class="nav-link <?=($pageName=='addLink')?'active':''?>">
                                <i class="nav-icon fas fa-cog"></i>
                                <p>Setting
                                   <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview <?=($pageName=='addLink')?'style="display: block;"':''?>">
                                <li class="nav-item">
                                    <a href="<?=base_url('admin/addLink');?>" class="nav-link">
                                        <i class="fa fa-plus nav-icon"></i>
                                        <p>Add Link</p>
                                    </a>
                                </li>
                            </ul>
                        </li>                       
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>