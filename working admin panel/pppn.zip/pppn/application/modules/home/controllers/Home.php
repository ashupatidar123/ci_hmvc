<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MX_Controller
{
	function __construct(){
		parent::__construct();
		
	}
	public function index(){
		echo "index test";
	}

	public function test(){
		echo "test function";
	}

	
}//class end
