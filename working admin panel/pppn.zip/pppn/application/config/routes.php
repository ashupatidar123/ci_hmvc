<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//$route['default_controller'] = 'welcome';
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


// Admin routes start
$route['admin'] = 'admin/login';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/logout']    = 'admin/dashboard/logout';

$route['admin/changePassword'] 		= 'admin/profile/changePassword';
$route['admin/profile'] 			= 'admin/profile/profile';

$route['admin/user/list'] 			= 'admin/user/list';
$route['admin/user/list/(:any)'] 	= 'admin/user/list/$1';
$route['admin/user/edit/(:any)'] 	= 'admin/user/edit/$1';

$route['admin/ajax/list'] 			= 'admin/ajax/list';
$route['admin/ajax/list/(:any)'] 	= 'admin/ajax/list/$1';
$route['admin/ajax/edit/(:any)'] 	= 'admin/ajax/edit/$1';

$route['admin/apartment/add'] 			= 'admin/apartment/add';
$route['admin/apartment/list'] 		    = 'admin/apartment/list';
$route['admin/apartment/list/(:any)'] 	= 'admin/apartment/list/$1';
$route['admin/apartment/edit/(:any)']	= 'admin/apartment/edit/$1';

$route['admin/addLink'] 			= 'admin/setting/addLink';
// Admin routes end