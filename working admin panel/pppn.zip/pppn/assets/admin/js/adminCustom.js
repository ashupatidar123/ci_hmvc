function alt(data=''){
	alert(data); 
	return false;
}
function snackbarMsg(msg='success',reload='',time='3000') {        
    $('#snackbar').html('');
    $('#snackbar').html(msg);
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show","");},time);
    if(reload=='refresh'){
    	setTimeout(function () { location.reload(1); }, time);    	
    }
    else if(reload!=''){
    	setTimeout(function () { window.location=reload; }, time);
    }else{
    	return false;
    }

}
function timeOUT(class_id_name='',reload='',time='2800'){
	setTimeout(function() {         
        $(class_id_name).removeClass('alert alert-danger');
		$(class_id_name).removeClass('alert alert-success'); 
		$(class_id_name).html('');
    },time);
    if(reload=='refresh'){
    	setTimeout(function () { location.reload(1); }, time);    	
    }
    else if(reload!=''){
    	setTimeout(function () { window.location=reload; }, time);
    }else{
    	return false;
    }
}


function errorMsg(msg='Field is required.',time='2500'){
	swal({
		title: msg,
  		buttons: true,
		timer: time,
		icon: "warning",
	});
	return false;
}


function successMsg(msg='Success.',time='2500'){
	swal({
		title: msg,
  		buttons: true,
		timer: time,
		icon: "success",
	});
	return false;
}

function confirmMsg(msg='Are you sure to delete ?'){
	swal({
	  	title: msg,
	  	text: "Once deleted, you will not be able to recover this imaginary file!",
	  	icon: "warning",
	  	buttons: true,
	  	dangerMode: true,
	})
	.then((willDelete) => {
	  	if(willDelete) {
	    	return true;
	  	}else {
	    	return false;
	  	}
	});
}

function checkInput(type='number')
{
    if(type=='number'){
    	var regex = new RegExp("^[0-9+.]+$");
	    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	    if (!regex.test(key)) {
	        event.preventDefault();
	        return false;
	    }else{
	        return true;
	    }
	}
	else if(type=='removePlus'){
    	var regex = new RegExp("^[0-9.]+$");
	    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	    if (!regex.test(key)) {
	        event.preventDefault();
	        return false;
	    }else{
	        return true;
	    }
	}

}

// =================================================

function changePassword(form_Data=''){
	
	$.ajax({
	    method:"POST",
	    url:base_url+"admin/profile/updatePassword",
	    contentType: false,
	    processData: false,
	    data: form_Data,
	    beforeSend: function() {
	      	$('.addLoader').addClass('fa fa-circle-o-notch fa-spin');
	    },

	    success:function(resp)
	    {		    
		    if(resp=='fail'){
		    	$('.addMsg').addClass('alert alert-danger');
		    	$('.addMsg').html('Interviewer updation failed..');
		    }
		    if(resp=='notMatch'){
		    	$('.addMsg').addClass('alert alert-danger');
		    	$('.addMsg').html('Oops! Old password is wrong.');
		    }
		    else if(resp=='success'){
		    	$('.addMsg').addClass('alert alert-success');
		    	$('.addMsg').html('Password updated successfully.');
		    	timeOUT('.addMsg','refresh');
		    }
		    if(resp!=''){
		    	$('.addLoader').removeClass('fa fa-circle-o-notch fa-spin');
		    	timeOUT('.addMsg');
		    }else{
		    	window.location.reload();
		    }		    
	    }
  	});
}

function updateUser(form_Data=''){
	
	$.ajax({
	    method:"POST",
	    url:base_url+"admin/users/updateUser",
	    contentType: false,
	    processData: false,
	    data: form_Data,
	    beforeSend: function() {
	      	$('.addLoader').addClass('fa fa-circle-o-notch fa-spin');
	    },

	    success:function(resp)
	    {		    
		    if(resp=='fail'){
		    	$('.addMsg').addClass('alert alert-danger');
		    	$('.addMsg').html('User updation failed..');
		    }
		    else if(resp=='success'){
		    	$('.addMsg').addClass('alert alert-success');
		    	$('.addMsg').html('User updated successfully.');
		    	timeOUT('.addMsg','refresh');
		    }
		    if(resp!=''){
		    	$('.addLoader').removeClass('fa fa-circle-o-notch fa-spin');
		    	timeOUT('.addMsg');
		    }else{
		    	window.location.reload();
		    }		    
	    }
  	});
}

function adminSubmit(pagename=''){

	if(pagename=='change_password'){
		$('.err').html('');
		
		var opass  = $('input[name="opass"]').val();
		var npass  = $('input[name="npass"]').val();
	    var cpass  = $('input[name="cpass"]').val();

	    if(opass==''){
	      	$('#opassErr').html('Old password is required.');
	    }
	    if(npass==''){
	      	$('#npassErr').html('New password is required.');
	    }
	    if(cpass==''){
	      	$('#cpassErr').html('confirm password is required.');
	    }

	    if(opass=='' || npass=='' || cpass==''){
	    	return false;
	    }
	    else if(npass !=cpass) {
	        $("#cpassErr").html('Confirm password does not match.');
	        return false;
	    }

		var form_Data = new FormData($('#changePassword')[0]);
		changePassword(form_Data);
	}

	if(pagename=='update_user'){
		$('.err').html('');

		var form_Data = new FormData($('#updateUser')[0]);
		updateUser(form_Data);
	}
}

